# Task 5: Data Analysis on CSV Files

This project analyzes sales data using Pandas in a Jupyter Notebook.

## Instructions:
1. Open the notebook.
2. Run all cells.
3. View the bar chart of revenue by category.